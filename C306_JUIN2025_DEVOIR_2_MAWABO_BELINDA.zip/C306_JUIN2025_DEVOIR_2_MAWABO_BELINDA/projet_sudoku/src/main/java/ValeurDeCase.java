public interface ValeurDeCase {
    char getValeur();
}