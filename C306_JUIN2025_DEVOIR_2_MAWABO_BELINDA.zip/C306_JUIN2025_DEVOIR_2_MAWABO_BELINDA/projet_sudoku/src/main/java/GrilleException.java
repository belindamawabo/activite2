public class GrilleException extends Exception {
    public GrilleException(String message) {
        super(message);
    }
}

