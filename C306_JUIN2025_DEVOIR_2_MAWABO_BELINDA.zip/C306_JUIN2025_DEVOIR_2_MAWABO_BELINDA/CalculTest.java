import static org.junit.jupiter.api.Assertions.*;;
import org.junit.jupiter.api.Test;
import exercice.calcul.Calcul;
 public class CalculTest {

  @Test
  public void testConstructeur() {
    new Calcul();
  }
  
  @Test
  public void testSomme() {
    assertEquals(5, Calcul.somme(2, 3));
	assertEquals(0, Calcul.somme(-2, 2));  // Cas avec nombre négatif
    assertEquals(-5, Calcul.somme(-2, -3));  // Cas avec deux nombres négatifs
	assertEquals(0, Calcul.somme(0, 0));  // Cas avec deux nombres null
  }
 
  @Test
  public void testNoteBornee() {
    assertEquals(20.0, Calcul.noteBornee(25.0, 0.0, 20.0));  // Test avec une note supérieure à la borne supérieure
    assertEquals(0.0, Calcul.noteBornee(-2.0, 0.0, 20.0));   // Test avec une note inférieure à la borne inférieure
    assertEquals(12.5, Calcul.noteBornee(12.5, 0.0, 20.0));  // Test avec une note dans la plage des bornes
    assertEquals(20.0, Calcul.noteBornee(30.0, 0.0, 20.0));  // Test avec une note dépassant la borne supérieure
    assertEquals(0.0, Calcul.noteBornee(-5.0, 0.0, 20.0));   // Test avec une note inférieure à la borne inférieure
  }
 
  @Test
  public void testDivision() {
    assertEquals(4, Calcul.division(8, 2));  // Cas normal
    assertEquals(-5, Calcul.division(-10, 2));  // Cas avec un nombre négatif
    assertThrows(IllegalArgumentException.class, () -> Calcul.division(10, 0));  // Test de la division par zéro
  }
}