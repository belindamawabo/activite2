import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.Test;
import exercice.calcul.Calcul;
 public class CalculTest {
 @Test
 public void testConstructeur() {
 new Calcul();
 }
 @Test
 public void testSomme() {
 assertEquals(5, Calcul.somme(2, 3));
 }
 @Test
 public void testDivision() {
 assertEquals(4, Calcul.division(8, 2));
 }
}