// Creation package

package exercice.calcul;


/**
 * Classe Calcul permettant d effectuer divers calculs.
 *
 *@author MAWABO BELINDA
 *@version 1.0
 */
 
public final class Calcul {
  
  /** Calcul la somme de deux nombres. 
   *
   * @param nombre1 Premier entier
   * @param nombre2 Deuxième entier
   * @return La somme de nombre1 et nombre2
   **/
  public static int somme(final int nombre1, final int nombre2) {
    return nombre1 + nombre2;
  }
  
  /**
   * Renvoie la note, bornée par les valeurs min et max, exemple.
   *   noteBornee(12.5,0.0,20.0) doit renvoyer 12.2
   *   noteBornee(25.0,0.0,20.0) doit renvoyer 20.0
   *   noteBornee(-2.0,0.0,20.0) doit renvoyer  0.0
   *
   * @param note La note à évaluer.
   * @param min  La valeur minimale autorisée.
   * @param max  La valeur maximale autorisée.
   * @return La note ajustée aux bornes si nécessaire.
   */  
  public static double noteBornee(final double note, final double min, final double max) {
    double resultat = note;
    if (note >= max) {
      resultat = max;
    }
    if (note <= min) {
      resultat = min;
    }
    return resultat;
  }
  
  /** 
   * Effectue la division entre deux entiers.
   *
   * @param entier1 Le numérateur.
   * @param entier2 Le dénominateur (doit être non nul).
   * @return Le résultat de la division.
   * @throws IllegalArgumentException Si entier2 est égal à 0.
   */
  public static int division(final int entier1, final int entier2) {
    if (entier2 == 0) {
      throw new IllegalArgumentException("entier2 ne doit pas etre 0");
    }
    return entier1 / entier2;
  }
}