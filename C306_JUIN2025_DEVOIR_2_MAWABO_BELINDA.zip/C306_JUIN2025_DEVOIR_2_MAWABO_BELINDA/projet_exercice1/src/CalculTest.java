import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.Test;
import exercice.calcul.Calcul;
 public class CalculTest {
 @Test
 public void testConstructeur() {
 new Calcul();
 }
 @Test
 public void testSomme() {
 assertEquals(5, Calcul.somme(2, 3));
 }
 
 @Test
 public void noteBornee() {
 assertEquals(20, Calcul.somme(25.0,0.0,20.0));
 assertEquals(0.0, Calcul.somme(-2.0,0.0,20.0));
 assertEquals(12.5, Calcul.somme(12.5,0.0,20.0));
 }
 
 
 @Test
 public void testDivision() {
 assertEquals(4, Calcul.division(8, 2));
 assertThrows(IllegalArgumentException.class, () -> Calcul.division(10,0));
 }
}